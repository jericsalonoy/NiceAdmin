
    <h1>TOKYO</h1>
    <p>Tokyo is the capital city of Japan. It is the most populous metropolitan area in the world, home to more than 37 million people.</p>
    <p>Located on the eastern coast of Honshu, Tokyo blends modern skyscrapers with traditional temples, and is a global hub for technology, culture, and finance.</p>